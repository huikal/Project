package com.example.simplelogin;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class SimpleLoginApplication {

	public static void main(String[] args) {
		SpringApplication.run(SimpleLoginApplication.class, args);
	}

}
